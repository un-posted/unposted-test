import { Component, EventEmitter, HostListener, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { User } from '@angular/fire/auth';
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  imports: [RouterModule, FormsModule, CommonModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.scss'
})
export class Navbar implements OnInit, OnDestroy {
userMenuOpen = false;
  mobileUserMenuOpen = false;
  showAnnouncement = true;
  user: User | null = null;
  private userSubscription?: any;
  
  @Input() isOpen = false;
  @Output() closeModalEvent = new EventEmitter<void>();
  @Output() subscribeEvent = new EventEmitter<string>();

  constructor(private authService: AuthService)  {}

  ngOnInit() {
    // Subscribe to user authentication state

    this.userSubscription = this.authService.user$.subscribe(user => {
      this.user = user;
      console.log('User state changed:', user);
    });

    
    console.log(this.user )
    console.log(this.authService.user$)
    // Close menus when clicking outside
    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      if (!target?.closest('.navbar-right') && 
          !target?.closest('.mobile-user-menu') && 
          !target?.closest('.profile-nav')) {
        this.userMenuOpen = false;
        this.mobileUserMenuOpen = false;
      }
    });
  }

  ngOnDestroy() {
    if (this.userSubscription) {
      this.userSubscription.unsubscribe();
    }
  }

  toggleUserMenu() {
    this.userMenuOpen = !this.userMenuOpen;
  }

  closeUserMenu() {
    this.userMenuOpen = false;
  }

  toggleMobileUserMenu() {
    this.mobileUserMenuOpen = !this.mobileUserMenuOpen;
  }

  closeMobileUserMenu() {
    this.mobileUserMenuOpen = false;
  }

  getUserInitial(): string {
    if (!this.user) return 'U';
    console.log(this.user)
    // Try to get from display name first
    if (this.user.displayName) {
      return this.user.displayName.charAt(0).toUpperCase();
    }
    
    // Fallback to email
    if (this.user.email) {
      return this.user.email.charAt(0).toUpperCase();
    }
    
    return 'U';
  }

  getUserName(): string {
    if (!this.user) return 'User';
    
    // Try display name first
    if (this.user.displayName) {
      return this.user.displayName;
    }
    
    // Fallback to email username
    if (this.user.email) {
      return this.user.email.split('@')[0];
    }
    
    return 'User';
  }

  async logout() {
    try {
      await this.authService.logout();
      this.closeUserMenu();
      this.closeMobileUserMenu();
      console.log('Logout successful');
      // Optionally redirect to home page
      // this.router.navigate(['/']);
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  openSubscribeModal(event: Event) {
    event.preventDefault();
    this.isOpen = true;
    console.log('Open subscribe modal');
  }

  email = '';

  closeModal() {
    this.isOpen = false;
    this.closeModalEvent.emit();
  }

  onOverlayClick(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }

  onSubmit() {
    if (this.email) {
      this.subscribeEvent.emit(this.email);
      this.email = '';
      this.closeModal();
    }
  }

  // Add these properties to your component class
notificationsOpen: boolean = false;
notifications: any[] = []; // Replace with your notification model
hasUnreadNotifications: boolean = false;

// Toggle notifications method
toggleNotifications(): void {
  this.notificationsOpen = !this.notificationsOpen;
  
  // Mark notifications as read when opened
  if (this.notificationsOpen && this.hasUnreadNotifications) {
    this.markNotificationsAsRead();
  }
}

// Close notifications when clicking outside
closeNotifications(): void {
  this.notificationsOpen = false;
}

// Mark all notifications as read
markNotificationsAsRead(): void {
  this.hasUnreadNotifications = false;
  // Update notifications in your backend/service
  // this.notificationService.markAllAsRead().subscribe();
}

// Load notifications (call this in ngOnInit or when needed)
loadNotifications(): void {
  // Replace with your actual service call
  // this.notificationService.getNotifications().subscribe(notifications => {
  //   this.notifications = notifications;
  //   this.hasUnreadNotifications = notifications.some(n => !n.isRead);
  // });
  
  // Mock data for demonstration
  this.notifications = [
    {
      id: 1,
      title: 'New story published',
      message: 'Your story "Adventures in Code" has been published successfully.',
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      isRead: false,
      type: 'success'
    },
    {
      id: 2,
      title: 'New follower',
      message: 'John Doe started following you.',
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      isRead: false,
      type: 'info'
    },
    {
      id: 3,
      title: 'Comment on your story',
      message: 'Someone commented on your story "Tech Insights".',
      timestamp: new Date(Date.now() - 86400000), // 1 day ago
      isRead: true,
      type: 'comment'
    }
  ];
  
  this.hasUnreadNotifications = this.notifications.some(n => !n.isRead);
}

// Handle individual notification click
onNotificationClick(notification: any): void {
  if (!notification.isRead) {
    notification.isRead = true;
    // Update in backend
    // this.notificationService.markAsRead(notification.id).subscribe();
  }
  
  // Navigate to relevant page based on notification type
  switch (notification.type) {
    case 'comment':
      // Navigate to story with comments
      // this.router.navigate(['/story', notification.storyId]);
      break;
    case 'follow':
      // Navigate to profile
      // this.router.navigate(['/profile', notification.userId]);
      break;
    default:
      // Handle other notification types
      break;
  }
  
  this.closeNotifications();
}

// Listen for clicks outside notifications dropdown
@HostListener('document:click', ['$event'])
onDocumentClick(event: Event): void {
  const target = event.target as HTMLElement;
  const notificationBell = document.querySelector('.notification-bell');
  const notificationDropdown = document.querySelector('.notification-dropdown');
  
  if (this.notificationsOpen && 
      !notificationBell?.contains(target) && 
      !notificationDropdown?.contains(target)) {
    this.closeNotifications();
  }
}

// Add this helper method to your component
getTimeAgo(timestamp: Date): string {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - timestamp.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return 'Just now';
  }
  
  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) {
    return `${diffInMinutes}m ago`;
  }
  
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) {
    return `${diffInHours}h ago`;
  }
  
  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays < 7) {
    return `${diffInDays}d ago`;
  }
  
  const diffInWeeks = Math.floor(diffInDays / 7);
  if (diffInWeeks < 4) {
    return `${diffInWeeks}w ago`;
  }
  
  const diffInMonths = Math.floor(diffInDays / 30);
  if (diffInMonths < 12) {
    return `${diffInMonths}mo ago`;
  }
  
  const diffInYears = Math.floor(diffInDays / 365);
  return `${diffInYears}y ago`;
}

}
