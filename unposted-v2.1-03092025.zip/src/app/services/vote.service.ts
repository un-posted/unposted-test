// services/vote.service.ts
import { Injectable, inject } from '@angular/core';
import { Firestore, doc, setDoc, deleteDoc, getDoc, updateDoc, increment } from '@angular/fire/firestore';
import { Vote } from '../models';

@Injectable({ providedIn: 'root' })
export class VoteService {
  private firestore = inject(Firestore);

  

  async toggleVote(storyId: string, userId: string): Promise<void> {
    const ref = doc(this.firestore, `stories/${storyId}/votes/${userId}`);
    const snap = await getDoc(ref);

    const storyRef = doc(this.firestore, `stories/${storyId}`);

    if (snap.exists()) {
      // user already voted → remove vote
      await deleteDoc(ref);
      await updateDoc(storyRef, { 'stats.voteCount': increment(-1) });
    } else {
      // user hasn’t voted → add vote
      await setDoc(ref, {
        storyId,
        userId,
        createdAt: new Date()
      });
      await updateDoc(storyRef, { 'stats.voteCount': increment(1) });
    }
  }


  async countVotes(storyId: string): Promise<number> {
    const storyRef = doc(this.firestore, `stories/${storyId}`);
    const storySnap = await getDoc(storyRef);

    if (storySnap.exists()) {
      const data = storySnap.data();
      return data?.['stats']?.voteCount ?? 0;
    }
    return 0;
  }

  async hasVoted(storyId: string, userId: string): Promise<boolean> {
    const ref = doc(this.firestore, `stories/${storyId}/votes/${userId}`);
    const snap = await getDoc(ref);
    return snap.exists();
  }
}
