import { Component } from '@angular/core';

@Component({
  selector: 'app-write',
  imports: [],
  templateUrl: './write.html',
  styleUrl: './write.scss'
})
export class Write {

}
