import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { User } from '@angular/fire/auth';
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  imports: [RouterModule, FormsModule, CommonModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.scss'
})
export class Navbar implements OnInit, OnDestroy {
userMenuOpen = false;
  mobileUserMenuOpen = false;
  showAnnouncement = true;
  user: User | null = null;
  private userSubscription?: Subscription;
  
  @Input() isOpen = false;
  @Output() closeModalEvent = new EventEmitter<void>();
  @Output() subscribeEvent = new EventEmitter<string>();

  constructor(private authService: AuthService)  {}

  ngOnInit() {
    // Subscribe to user authentication state
    this.user = this.authService.user;

    // Close menus when clicking outside
    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      if (!target?.closest('.navbar-right') && 
          !target?.closest('.mobile-user-menu') && 
          !target?.closest('.profile-nav')) {
        this.userMenuOpen = false;
        this.mobileUserMenuOpen = false;
      }
    });
  }

  ngOnDestroy() {
    if (this.userSubscription) {
      this.userSubscription.unsubscribe();
    }
  }

  toggleUserMenu() {
    this.userMenuOpen = !this.userMenuOpen;
  }

  closeUserMenu() {
    this.userMenuOpen = false;
  }

  toggleMobileUserMenu() {
    this.mobileUserMenuOpen = !this.mobileUserMenuOpen;
  }

  closeMobileUserMenu() {
    this.mobileUserMenuOpen = false;
  }

  getUserInitial(): string {
    if (!this.user) return 'U';
    console.log(this.user)
    // Try to get from display name first
    if (this.user.displayName) {
      return this.user.displayName.charAt(0).toUpperCase();
    }
    
    // Fallback to email
    if (this.user.email) {
      return this.user.email.charAt(0).toUpperCase();
    }
    
    return 'U';
  }

  getUserName(): string {
    if (!this.user) return 'User';
    
    // Try display name first
    if (this.user.displayName) {
      return this.user.displayName;
    }
    
    // Fallback to email username
    if (this.user.email) {
      return this.user.email.split('@')[0];
    }
    
    return 'User';
  }

  async logout() {
    try {
      await this.authService.logout();
      this.closeUserMenu();
      this.closeMobileUserMenu();
      console.log('Logout successful');
      // Optionally redirect to home page
      // this.router.navigate(['/']);
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  openSubscribeModal(event: Event) {
    event.preventDefault();
    this.isOpen = true;
    console.log('Open subscribe modal');
  }

  email = '';

  closeModal() {
    this.isOpen = false;
    this.closeModalEvent.emit();
  }

  onOverlayClick(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }

  onSubmit() {
    if (this.email) {
      this.subscribeEvent.emit(this.email);
      this.email = '';
      this.closeModal();
    }
  }
}
