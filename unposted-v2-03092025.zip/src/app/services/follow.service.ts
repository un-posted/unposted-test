// services/follow.service.ts
import { Injectable, inject } from '@angular/core';
import { Firestore, doc, setDoc, deleteDoc, getDoc, updateDoc, increment } from '@angular/fire/firestore';
import { Follow } from '../models/follow';

@Injectable({ providedIn: 'root' })
export class FollowService {
  private firestore = inject(Firestore);

  async toggleFollow(follow: Follow): Promise<void> {
    const ref = doc(this.firestore, `follows/${follow.followerId}_${follow.followingId}`);
    const snap = await getDoc(ref);

    const profileRef = doc(this.firestore, `profiles/${follow.followingId}`);

    if (snap.exists()) {
      await deleteDoc(ref);
      await updateDoc(profileRef, { nbFollowers: increment(-1) });
    } else {
      await setDoc(ref, follow);
      await updateDoc(profileRef, { nbFollowers: increment(1) });
    }
  }
}
