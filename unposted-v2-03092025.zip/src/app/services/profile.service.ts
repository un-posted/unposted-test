import { Injectable, inject } from '@angular/core';
import { Firestore, doc, updateDoc, getDoc } from '@angular/fire/firestore';
import { Profile } from '../models/user-profile';

@Injectable({ providedIn: 'root' })
export class ProfileService {
  private firestore = inject(Firestore);

  async getProfile(userId: string): Promise<Profile | null> {
    const ref = doc(this.firestore, `profiles/${userId}`);
    const snap = await getDoc(ref);
    return snap.exists() ? (snap.data() as Profile) : null;
  }

  async updateProfile(userId: string, data: Partial<Profile>): Promise<void> {
    const ref = doc(this.firestore, `profiles/${userId}`);
    await updateDoc(ref, { ...data, updatedAt: new Date() });
  }
}
