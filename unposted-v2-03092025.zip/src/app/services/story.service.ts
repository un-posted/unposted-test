// services/story.service.ts
import { Injectable, inject } from '@angular/core';
import { Firestore, doc, setDoc, getDoc, updateDoc, addDoc, collection, serverTimestamp } from '@angular/fire/firestore';
import { Story } from '../models';

@Injectable({ providedIn: 'root' })
export class StoryService {
  private firestore = inject(Firestore);

  async createStory(story: Story): Promise<void> {
    const ref = doc(this.firestore, `stories/${story.id}`);
    await setDoc(ref, {
      ...story,
      createdAt: new Date(),
      updatedAt: new Date()
    });
  }

  async updateStory(storyId: string, data: Partial<Story>): Promise<void> {
    const ref = doc(this.firestore, `stories/${storyId}`);
    await updateDoc(ref, { ...data, updatedAt: new Date() });
  }

  async getStory(storyId: string): Promise<Story | null> {
    const ref = doc(this.firestore, `stories/${storyId}`);
    const snap = await getDoc(ref);
    return snap.exists() ? (snap.data() as Story) : null;
  }
}
