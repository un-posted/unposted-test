import { Routes } from '@angular/router';
import { Stories } from './components/stories/stories';
import { Profile } from './components/profile/profile';
import { About } from './components/about/about';
import { Login } from './components/login/login';
import { Register } from './components/register/register';
import { Story } from './components/story/story';
import { Write } from './components/write/write';

export const routes: Routes = [
  { path: '', component: Stories },
  { path: 'stories', component: Stories },
  
  // Individual story routes
  { path: 'story/:id', component: Story }, // Dynamic story by ID
  { path: 'story', component: Story },
  { path: 'article', redirectTo: '/stories', pathMatch: 'full' }, // Redirect old route
  
  // Other pages
  { path: 'about', component: About },
  
  // Auth-protected routes
  { path: 'write', component: Write },

  // Authentication routes
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  
  // User profile and management (if needed later)
  { path: 'profile', component: Profile},
  { path: 'profile/:id', component: Profile },
  // { path: 'my-stories', component: MyStoriesComponent, canActivate: [authGuard] },
  
  // Wildcard route - must be last
  { path: '**', redirectTo: '/stories' }
];