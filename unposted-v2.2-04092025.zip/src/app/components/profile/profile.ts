import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { getAuth, UserProfile } from '@angular/fire/auth';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { Story, Bookmark } from '../../models';
import { ProfileService } from '../../services/profile.service';
import { ViewsService } from '../../services/views.service';
import { VoteService } from '../../services/vote.service';
import { AuthService } from '../../services/auth.service';
import { StoryService } from '../../services/story.service';
import { BookmarkService } from '../../services/bookmark.service';
import { FollowService } from '../../services/follow.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  requirement?: number;
}

@Component({
  selector: 'app-profile',
  imports: [FormsModule, CommonModule],
  templateUrl: './profile.html',
  styleUrl: './profile.scss'
})
export class Profile implements OnInit, OnDestroy {
    
  @ViewChild('nameInput') nameInput!: ElementRef;
  @ViewChild('bioInput') bioInput!: ElementRef;

  currentUser = getAuth().currentUser;

  // Component state
  userProfile: any = null;
  stories: Story[] = [];
  drafts: Story[] = [];
  bookmarks: Bookmark[] = [];
  
  activeTab: 'drafts' | 'articles' | 'bookmarks' = 'drafts';
  loading = true;
  savingProfile = false;
  loadingStats = false;
  loadingBadges = false;
  deletingItem: string | null = null;
  
  // Edit state
  editingName = false;
  editingBio = false;
  tempName = '';
  tempBio = '';

  // Auto-save timers
  private bioSaveTimeout: any = null;
  private nameSaveTimeout: any = null;

  // Gamification state
  badges: Badge[] = [];
  isOwnProfile = false;
  isFollowing = false;
  followLoading = false;

  // Default avatar
  defaultAvatar = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIwIiBoZWlnaHQ9IjEyMCIgdmlld0JveD0iMCAwIDEyMCAxMjAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjAiIGhlaWdodD0iMTIwIiByeD0iNjAiIGZpbGw9IiNlNmIxN2EiLz4KPHN2ZyB4PSIzMCIgeT0iMzAiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSI+CjxwYXRoIGQ9Im0zIDkgOS0xIDktMW0tMSAyIDEwIDEwaDEwbC04LTEwbS0xLTEwSDhsLTggMTB2MTBsOC0xMVoiLz4KPC9zdmc+Cjwvc3ZnPgo=';
  
  private destroy$ = new Subject<void>();

  constructor(
    private profileService: ProfileService,
    private route: ActivatedRoute,
    private viewsService: ViewsService,
    private voteService: VoteService,
    private storyService: StoryService,
    private bookmarkService: BookmarkService,
    private authService: AuthService,
    private followService: FollowService,
    private router: Router
  ) {}

  ngOnInit() {
  // Set initial tab from session storage
  this.activeTab = this.getInitialTab();

  this.route.paramMap
    .pipe(takeUntil(this.destroy$))
    .subscribe(async paramMap => {
      const uid: any = paramMap.get('id');
      
      // Get current user ID - prioritize authService
      const currentUserId = this.authService.user?.uid || this.currentUser?.uid ;
      
      // Determine if this is own profile
      this.isOwnProfile = (!uid || uid === currentUserId);

      if (!currentUserId) {
        console.error('Anonymous user must provide profile ID in route');
        // Handle this case - maybe redirect to home or show error
        this.router.navigate(['/login']);
        return;
      }

      // If not own profile and not showing articles, switch to articles
      if (!this.isOwnProfile && this.activeTab !== 'articles') {
        this.activeTab = 'articles';
      }

      // Load profile data
      await this.loadProfileData(uid);
    });
}

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    
    // Clear any pending timeouts
    if (this.bioSaveTimeout) clearTimeout(this.bioSaveTimeout);
    if (this.nameSaveTimeout) clearTimeout(this.nameSaveTimeout);
  }

  private getInitialTab(): 'drafts' | 'articles' | 'bookmarks' {
    const saved = sessionStorage.getItem('profileActiveTab') as any;
    
    if (!this.isOwnProfile) {
      return 'articles';
    }
    
    return saved && ['drafts', 'articles', 'bookmarks'].includes(saved) 
      ? saved 
      : 'drafts';
  }

  async loadProfileData(uid?: string) {
  this.loading = true;
  this.loadingStats = true;
  this.loadingBadges = true;
  
  try {
    // Better user ID resolution - prioritize authService over currentUser
    const currentUserId = this.authService.user?.uid || this.currentUser?.uid;
    const targetUid = uid || currentUserId;

    if (!targetUid) {
      console.error('No user ID available for profile loading');
      this.userProfile = null;
      this.loading = false;
      this.loadingStats = false;
      this.loadingBadges = false;
      return;
    }

    console.log('Loading profile for UID:', targetUid); // Debug log

    // Load profile first (fastest)
    const profile = await this.profileService.getProfile(targetUid);

    if (!profile) {
      console.error('Profile not found for UID:', targetUid);
      this.userProfile = null;
      this.loading = false;
      this.loadingStats = false;
      this.loadingBadges = false;
      return;
    }
    
    profile.nbUpvotes = 0;
    profile.nbViews = 0;
    this.userProfile = profile;
    this.loading = false; // Show basic profile info immediately

    // Rest of the method remains the same...
    let loadPromises: [Promise<Story[]>, Promise<Story[]>, Promise<Bookmark[]>];
    
    if (this.isOwnProfile) {
      loadPromises = [
        this.storyService.getDraftsByAuthor(targetUid),
        this.storyService.getPublishedByAuthor(targetUid),
        this.bookmarkService.getUserBookmarks(targetUid),
      ];
    } else {
      loadPromises = [
        Promise.resolve([] as Story[]),
        this.storyService.getPublishedByAuthor(targetUid),
        this.bookmarkService.getUserBookmarks(targetUid),
      ];
    }

    const [drafts, stories, bookmarks] = await Promise.all(loadPromises);

    this.drafts = drafts;
    this.stories = stories;
    this.bookmarks = bookmarks;
    
    // Load stats progressively
    await this.loadStoryViewCounts();
    this.loadingStats = false;

    // Load badges last (least critical)
    this.initializeBadges();
    this.updateBadgeProgress();
    this.loadingBadges = false;

    // Check if following (for other users' profiles)
    if (!this.isOwnProfile && this.currentUser) {
      this.isFollowing = await this.followService.isFollowing(this.currentUser.uid, targetUid);
    }
  } catch (e) {
    console.error('Error loading profile:', e);
    this.userProfile = null;
    this.showNotification('Failed to load profile data', 'error');
  } finally {
    this.loading = false;
    this.loadingStats = false;
    this.loadingBadges = false;
  }
}
  async loadStoryViewCounts() {
    for (const story of this.stories) {
      try {
        story.stats.readCount = await this.viewsService.getViewCount(story.id);
        story.stats.voteCount = await this.voteService.countVotes(story.id);
        this.userProfile.nbViews += story.stats.readCount;
        this.userProfile.nbUpvotes += story.stats.voteCount;
      } catch (error) {
        console.error('Error loading view count for story:', story.id, error);
        story.stats.readCount = 0;
      }
    }
  }

  async toggleFollow() {
    if (!this.currentUser || !this.userProfile || this.isOwnProfile) return;

    const me = this.currentUser.uid;
    const them = this.userProfile.uid;

    // Optimistic update - immediately update UI
    const wasFollowing = this.isFollowing;
    this.isFollowing = !this.isFollowing;
    this.userProfile.followersCount += this.isFollowing ? 1 : -1;
    
    this.followLoading = true;
    try {
      await this.followService.toggleFollow(me, them);
      this.showNotification(
        this.isFollowing ? 'Now following!' : 'Unfollowed',
        'success'
      );
    } catch (error) {
      // Revert optimistic update on error
      this.isFollowing = wasFollowing;
      this.userProfile.followersCount += wasFollowing ? 1 : -1;
      this.showNotification('Failed to update follow status. Please try again.', 'error');
      console.error('Error toggling follow:', error);
    } finally {
      this.followLoading = false;
    }
  }

  // Enhanced keyboard navigation
  onKeyDown(event: KeyboardEvent, action: string) {
    switch (action) {
      case 'name-edit':
        if (event.key === 'Enter') {
          event.preventDefault();
          this.saveName();
        } else if (event.key === 'Escape') {
          this.cancelNameEdit();
        }
        break;
      case 'bio-edit':
        if (event.key === 'Enter' && event.ctrlKey) {
          event.preventDefault();
          this.saveBio();
        } else if (event.key === 'Escape') {
          this.cancelBioEdit();
        }
        break;
    }
  }

  // Auto-save functionality
  onNameInput() {
    clearTimeout(this.nameSaveTimeout);
    this.nameSaveTimeout = setTimeout(() => {
      if (this.tempName !== (this.userProfile?.name || '') && this.tempName.trim()) {
        this.autoSaveName();
      }
    }, 2000);
  }

  onBioInput() {
    clearTimeout(this.bioSaveTimeout);
    this.bioSaveTimeout = setTimeout(() => {
      if (this.tempBio !== (this.userProfile?.bio || '')) {
        this.autoSaveBio();
      }
    }, 2000);
  }

  async autoSaveName() {
    try {
      await this.saveName();
    } catch (error) {
      this.showNotification('Failed to auto-save name', 'error');
    }
  }

  async autoSaveBio() {
    try {
      await this.saveBio();
    } catch (error) {
      this.showNotification('Failed to auto-save bio', 'error');
    }
  }

  // Enhanced empty states
  getEmptyStateMessage(tab: string): { title: string; subtitle: string; action?: string } {
    const messages : any = {
      'drafts': {
        title: 'No drafts yet',
        subtitle: 'Start writing your first draft to see it here.',
        action: 'Create Draft'
      },
      'articles': {
        title: this.isOwnProfile ? 'No published articles' : 'No articles yet',
        subtitle: this.isOwnProfile 
          ? 'Publish your first draft to see it here.' 
          : 'This user hasn\'t published any articles yet.'
      },
      'bookmarks': {
        title: 'No bookmarks yet',
        subtitle: 'Save interesting articles to read them later.'
      }
    };
    
    return messages[tab] || { title: 'Nothing here', subtitle: '' };
  }

  handleEmptyStateAction(tab: string) {
    switch (tab) {
      case 'drafts':
        this.createNewDraft();
        break;
      case 'articles':
        if (this.isOwnProfile) {
          this.router.navigate(['/editor']);
        }
        break;
    }
  }

  private showNotification(message: string, type: 'success' | 'error' | 'info' = 'success') {
    // Implement based on your notification system
    console.log(`${type.toUpperCase()}: ${message}`);
    
    // Example implementation with a simple toast-like system:
    // You can replace this with your actual notification service
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      background: ${type === 'error' ? '#dc3545' : type === 'success' ? '#28a745' : '#007bff'};
      color: white;
      border-radius: 6px;
      z-index: 10000;
      opacity: 0;
      transition: opacity 0.3s ease;
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => notification.style.opacity = '1', 100);
    setTimeout(() => {
      notification.style.opacity = '0';
      setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
  }

  // Performance optimization
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  // Tab navigation with persistence
  setActiveTab(tab: 'drafts' | 'articles' | 'bookmarks') {
    this.activeTab = tab;
    sessionStorage.setItem('profileActiveTab', tab);
  }

  // Rest of your existing methods with enhanced confirmation dialogs
  async confirmAction(action: string, itemName: string): Promise<boolean> {
    const messages : any = {
      'delete-draft': `Delete "${itemName}" draft? This cannot be undone.`,
      'remove-bookmark': `Remove "${itemName}" from bookmarks?`,
      'publish-draft': `Publish "${itemName}"? It will be visible to everyone.`
    };
    
    return confirm(messages[action] || `Are you sure you want to ${action}?`);
  }

  // Enhanced async operations with loading states
  async deleteDraft(draft: Story) {
    if (!await this.confirmAction('delete-draft', draft.title)) return;
    
    this.deletingItem = draft.id;
    try {
      // await this.storyService.deleteDraft(draft.id);
      this.drafts = this.drafts.filter(d => d.id !== draft.id);
      this.showNotification('Draft deleted successfully', 'success');
    } catch (error) {
      console.error('Error deleting draft:', error);
      this.showNotification('Failed to delete draft', 'error');
    } finally {
      this.deletingItem = null;
    }
  }

  async publishDraft(draft: Story) {
    if (!await this.confirmAction('publish-draft', draft.title)) return;
    
    this.deletingItem = draft.id; // Reuse loading state
    try {
      await this.storyService.updateStory(draft.id, { status: 'published' });
      await this.awardXP(25, 'Published a story');
      await this.updateWritingStreak();
      await this.loadProfileData();
      this.showNotification('Draft published successfully!', 'success');
    } catch (error) {
      console.error('Error publishing draft:', error);
      this.showNotification('Failed to publish draft', 'error');
    } finally {
      this.deletingItem = null;
    }
  }

  // Enhanced streak tracking with timezone awareness
  async updateWritingStreak() {
    if (!this.currentUser || !this.isOwnProfile || !this.userProfile) return;
    
    try {
      const today = this.getCurrentDate();
      const lastWriteDate = this.userProfile.lastWriteDate 
        ? this.formatDateForComparison(this.userProfile.lastWriteDate)
        : null;

      if (lastWriteDate === today) return;

      const yesterday = this.getYesterdayDate();
      let newStreak = 1;
      let streakBroken = false;
      
      if (lastWriteDate === yesterday) {
        newStreak = (this.userProfile.writingStreak || 0) + 1;
      } else if (lastWriteDate && lastWriteDate < yesterday) {
        streakBroken = true;
        newStreak = 1;
      }
      
      if (this.currentUser) {
        await this.profileService.updateProfile(this.currentUser.uid, {
          streaks: newStreak,
          lastWriteDay: new Date()
        });
      }

      this.userProfile.writingStreak = newStreak;
      this.userProfile.lastWriteDate = new Date().toISOString();

      if (streakBroken) {
        this.showStreakBrokenNotification(this.userProfile.writingStreak || 0);
      } else if (newStreak > 1) {
        await this.awardStreakXP(newStreak);
      }
    } catch (error) {
      console.error('Error updating writing streak:', error);
    }
  }

  private getCurrentDate(): string {
    const now = new Date();
    return now.toLocaleDateString('en-CA');
  }

  private getYesterdayDate(): string {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.toLocaleDateString('en-CA');
  }

  private formatDateForComparison(date: any): string {
    const dateObj = date.toDate ? date.toDate() : new Date(date);
    return dateObj.toLocaleDateString('en-CA');
  }

  private async awardStreakXP(currentStreak: number) {
    let xpAmount = 0;
    let reason = '';
    
    if (currentStreak % 30 === 0) {
      xpAmount = 200;
      reason = `Maintained ${currentStreak}-day writing streak (monthly milestone)`;
    } else if (currentStreak % 7 === 0) {
      xpAmount = 50;
      reason = `Maintained ${currentStreak}-day writing streak (weekly milestone)`;
    } else if (currentStreak === 1) {
      xpAmount = 10;
      reason = 'Started a new writing streak';
    } else {
      xpAmount = 5;
      reason = `Maintained ${currentStreak}-day writing streak`;
    }
    
    if (xpAmount > 0) {
      await this.awardXP(xpAmount, reason);
    }
  }

  private showStreakBrokenNotification(previousStreak: number) {
    if (previousStreak > 3) {
      this.showNotification(`Your ${previousStreak}-day writing streak was broken! Start a new one today!`, 'info');
    }
  }

  isStreakCurrent(): boolean {
    if (!this.userProfile?.lastWriteDate) return false;
    
    const lastWriteDate = new Date(this.userProfile.lastWriteDate);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    return (
      lastWriteDate.toDateString() === today.toDateString() ||
      lastWriteDate.toDateString() === yesterday.toDateString()
    );
  }

  getStreakIcon(streak: number): string {
    if (streak >= 100) return '🏆';
    if (streak >= 30) return '🌟';
    if (streak >= 7) return '🔥';
    return '📅';
  }

  initializeBadges() {
    this.badges = [
      {
        id: 'first-draft',
        name: 'First Draft',
        description: 'Created your first draft',
        icon: '📝',
        unlocked: true
      },
      {
        id: 'first-publish',
        name: 'Author',
        description: 'Published your first story',
        icon: '📚',
        unlocked: false
      },
      {
        id: 'prolific-writer',
        name: 'Prolific Writer',
        description: 'Published 5 stories',
        icon: '✍️',
        unlocked: false,
        progress: 0,
        requirement: 5
      },
      {
        id: 'word-master',
        name: 'Word Master',
        description: 'Written 10,000 words total',
        icon: '📖',
        unlocked: false,
        progress: 0,
        requirement: 10000
      },
      {
        id: 'streak-novice',
        name: 'Consistent Writer',
        description: 'Maintained a 3-day writing streak',
        icon: '📅',
        unlocked: false,
        progress: 0,
        requirement: 3
      },
      {
        id: 'streak-warrior',
        name: 'Streak Warrior',
        description: 'Maintained a 7-day writing streak',
        icon: '🔥',
        unlocked: false,
        progress: 0,
        requirement: 7
      },
      {
        id: 'streak-champion',
        name: 'Streak Champion',
        description: 'Maintained a 30-day writing streak',
        icon: '🏆',
        unlocked: false,
        progress: 0,
        requirement: 30
      },
      {
        id: 'streak-legend',
        name: 'Writing Legend',
        description: 'Maintained a 100-day writing streak',
        icon: '🌟',
        unlocked: false,
        progress: 0,
        requirement: 100
      },
      {
        id: 'community-favorite',
        name: 'Community Favorite',
        description: 'Received 100 total votes',
        icon: '⭐',
        unlocked: false,
        progress: 0,
        requirement: 100
      },
      {
        id: 'bookworm',
        name: 'Bookworm',
        description: 'Bookmarked 20 stories',
        icon: '🔖',
        unlocked: false,
        progress: 0,
        requirement: 20
      }
    ];
  }

  updateBadgeProgress() {
    if (!this.userProfile) return;

    const stats = this.userProfile.stats || {};
    const totalVotes = this.calculateTotalVotes();

    this.badges.forEach(badge => {
      switch (badge.id) {
        case 'first-draft':
          badge.unlocked = true;
          break;
        case 'first-publish':
          badge.unlocked = (this.stories.length || 0) > 0;
          break;
        case 'prolific-writer':
          badge.progress = Math.min(this.stories.length || 0, badge.requirement!);
          badge.unlocked = (this.stories.length || 0) >= badge.requirement!;
          break;
        case 'word-master':
          badge.progress = Math.min(0, badge.requirement!);
          badge.unlocked = false;
          break;
        case 'streak-novice':
        case 'streak-warrior':
        case 'streak-champion':
        case 'streak-legend':
          const currentStreak = this.isStreakCurrent() ? this.userProfile?.writingStreak || 0 : 0;
          badge.progress = Math.min(currentStreak, badge.requirement!);
          badge.unlocked = currentStreak >= badge.requirement!;
          break;
        case 'community-favorite':
          badge.progress = Math.min(totalVotes, badge.requirement!);
          badge.unlocked = totalVotes >= badge.requirement!;
          break;
        case 'bookworm':
          badge.progress = Math.min(this.bookmarks.length || 0, badge.requirement!);
          console.log(badge.progress)
          console.log(this.bookmarks.length)
          badge.unlocked = (this.bookmarks.length || 0) >= badge.requirement!;
          break;
      }
    });
  }

  calculateTotalVotes(): number {
    return this.stories.reduce((total, story) => {
      return total + (story.stats.voteCount || 0);
    }, 0);
  }

  calculateTotalViews(): number {
    return this.stories.reduce((total, story) => {
      return total + (story.stats.readCount || 0);
    }, 0);
  }

  getXPProgress(): number {
    if (!this.userProfile) return 0;
    
    const currentXP = this.userProfile.xp || 0;
    const currentLevel = this.userProfile.level || 1;
    const currentLevelXP = this.getLevelXP(currentLevel);
    const nextLevelXP = this.getNextLevelXP();
    
    const levelXPRange = nextLevelXP - currentLevelXP;
    const currentLevelProgress = currentXP - currentLevelXP;
    
    return Math.max(0, Math.min(100, (currentLevelProgress / levelXPRange) * 100));
  }

  getLevelXP(level: number): number {
    return Math.pow(level - 1, 2) * 100;
  }

  getNextLevelXP(): number {
    const currentLevel = this.userProfile?.level || 1;
    return this.getLevelXP(currentLevel + 1);
  }

  getMotivationMessage(): string {
    if (!this.userProfile || !this.isOwnProfile) return '';

    const currentStreak = this.userProfile.writingStreak || 0;
    const unlockedBadges = this.badges.filter(b => b.unlocked).length;
    const totalBadges = this.badges.length;

    if (currentStreak > 0) {
      if (this.isStreakCurrent()) {
        if (currentStreak === 1) {
          return "You started a streak! Write again tomorrow to keep it going!";
        } else if (currentStreak < 3) {
          return `Keep your ${currentStreak}-day streak alive! ${3 - currentStreak} more days until your first streak badge!`;
        } else if (currentStreak < 7) {
          return `Keep your ${currentStreak}-day streak alive! ${7 - currentStreak} more days until Streak Warrior!`;
        } else if (currentStreak < 30) {
          return `Amazing ${currentStreak}-day streak! ${30 - currentStreak} more days until Streak Champion!`;
        } else if (currentStreak < 100) {
          return `Incredible ${currentStreak}-day streak! ${100 - currentStreak} more days until Writing Legend!`;
        } else {
          return `You're a Writing Legend with ${currentStreak} days! Keep the momentum going!`;
        }
      } else {
        return "Your streak is about to break! Write something today to keep it going!";
      }
    }

    const nearAchievements = this.badges.filter(badge => 
      !badge.unlocked && 
      badge.progress !== undefined && 
      badge.requirement !== undefined
    ).sort((a, b) => {
      if (a.id.includes('streak')) return -1;
      if (b.id.includes('streak')) return 1;
      return (b.progress! / b.requirement!) - (a.progress! / a.requirement!);
    });

    if (nearAchievements.length > 0) {
      const badge = nearAchievements[0];
      const progressPercentage = (badge.progress! / badge.requirement!) * 100;
      
      if (progressPercentage >= 80) {
        const remaining = badge.requirement! - badge.progress!;
        return `You're ${remaining} away from "${badge.name}"! ${this.getBadgeHint(badge.id)}`;
      }
    }

    if (this.drafts.length === 0) {
      return "Start a writing streak today! Create your first draft!";
    }

    if (this.stories.length === 0 && this.drafts.length > 0) {
      return "Publish a draft to start building your writing reputation!";
    }

    if (unlockedBadges < totalBadges) {
      return `${totalBadges - unlockedBadges} achievements waiting! Consistency is key.`;
    }

    return "Keep up the great work! Your consistency is inspiring.";
  }

  private getBadgeHint(badgeId: string): string {
    const hints: { [key: string]: string } = {
      'streak-novice': 'Write for 3 consecutive days!',
      'streak-warrior': 'Write every day for a full week!',
      'streak-champion': 'Maintain your daily writing for a month!',
      'streak-legend': 'The ultimate challenge - 100 days of writing!',
      'prolific-writer': 'Publish more stories to reach your goal!',
      'word-master': 'Keep writing - every word counts!',
      'community-favorite': 'Engage with the community to get more votes!',
      'bookworm': 'Discover and bookmark great content!'
    };
    
    return hints[badgeId] || '';
  }

  formatNumber(num: number | null | undefined): string {
    if (num === null || num === undefined) return "0";

    if (num >= 1_000_000) {
      return (num / 1_000_000).toFixed(1) + "M";
    }
    if (num >= 1_000) {
      return (num / 1_000).toFixed(1) + "K";
    }
    return num.toString();
  }

  startEditingName() {
    if (!this.isOwnProfile) return;
    
    this.editingName = true;
    this.tempName = this.userProfile?.displayName || '';
    setTimeout(() => {
      this.nameInput?.nativeElement?.focus();
    });
  }

  async saveName() {
    if (!this.userProfile || !this.tempName.trim() || !this.isOwnProfile) return;
    
    this.savingProfile = true;
    try {
        if (this.currentUser) {
            await this.profileService.updateProfile(this.currentUser.uid, {
              name: this.tempName.trim()
            });
      }
      
      if (this.userProfile) {
        this.userProfile.displayName = this.tempName.trim();
      }
      this.editingName = false;
      this.showNotification('Name updated successfully', 'success');
    } catch (error) {
      console.error('Error updating name:', error);
      this.showNotification('Failed to update name', 'error');
    } finally {
      this.savingProfile = false;
    }
  }

  cancelNameEdit() {
    this.editingName = false;
    this.tempName = '';
  }

  startEditingBio() {
    if (!this.isOwnProfile) return;
    
    this.editingBio = true;
    this.tempBio = this.userProfile?.bio || '';
    setTimeout(() => {
      this.bioInput?.nativeElement?.focus();
    });
  }

  async saveBio() {
    if (!this.userProfile || !this.isOwnProfile) return;
    
    this.savingProfile = true;
    try {
        if (this.currentUser) {
      await this.profileService.updateProfile(this.currentUser.uid, {
        bio: this.tempBio.trim()
      });}
      
      if (this.userProfile) {
        this.userProfile.bio = this.tempBio.trim();
      }
      this.editingBio = false;
      this.showNotification('Bio updated successfully', 'success');
    } catch (error) {
      console.error('Error updating bio:', error);
      this.showNotification('Failed to update bio', 'error');
    } finally {
      this.savingProfile = false;
    }
  }

  cancelBioEdit() {
    this.editingBio = false;
    this.tempBio = '';
  }

  async createNewDraft() {
    try {
      this.router.navigate(['/editor']);
      await this.awardXP(10, 'Created a new draft');
      await this.updateWritingStreak();
      this.showNotification('New draft created!', 'success');
    } catch (error) {
      console.error('Error creating new draft:', error);
      this.showNotification('Failed to create draft', 'error');
    }
  }

  editDraft(draft: Story) {
    this.router.navigate(['/editor', draft.id]);
  }

  readBookmark(bookmark: Bookmark) {
    if(bookmark.storyId) {
      this.router.navigate(['/story/', bookmark.storyId]);
    }
  }

  editBookmark(bookmark: Bookmark) {
    console.log('Edit bookmark:', bookmark.id);
  }

  async awardXP(amount: number, reason: string) {
    if (!this.currentUser || !this.userProfile) return;
    
    try {
      await this.profileService.awardUserXP(this.currentUser.uid, amount, reason);
      
      const oldLevel = this.userProfile.level || 1;
      this.userProfile.xp = (this.userProfile.xp || 0) + amount;
      this.userProfile.level = this.calculateLevel(this.userProfile.xp);
      
      if (this.userProfile.level > oldLevel) {
        this.showLevelUpNotification(this.userProfile.level);
      }
    } catch (error) {
      console.error('Error awarding XP:', error);
    }
  }

  calculateLevel(totalXP: number): number {
    return Math.floor(Math.sqrt(totalXP / 100)) + 1;
  }

  showLevelUpNotification(newLevel: number) {
    this.showNotification(`Level up! You're now level ${newLevel}!`, 'success');
  }

  formatDate(date: any): string {
    if (!date) return '';
    
    const dateObj = date.toDate ? date.toDate() : new Date(date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - dateObj.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  }

  getExcerpt(content: string, maxLength = 150): string {
    if (!content) return '';
    
    const plainText = content.replace(/<[^>]*>/g, '');
    return plainText.length > maxLength 
      ? plainText.substring(0, maxLength) + '...'
      : plainText;
  }

  calculateReadTime(content: string): number {
    if (!content) return 0;
    
    const words = content.trim().split(/\s+/).length;
    return Math.ceil(words / 200);
  }
}