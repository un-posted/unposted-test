import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Story, Bookmark } from '../../models';
import { StoryStatus } from '../../models/firestore';
import { AuthService } from '../../services/auth.service';
import { ProfileService } from '../../services/profile.service';
import { CommentService } from '../../services/comment.service';
import { StoryService } from '../../services/story.service';
import { VoteService } from '../../services/vote.service';
import { FormsModule } from '@angular/forms';
import { Timestamp } from '@angular/fire/firestore';
import { BookmarkService } from '../../services/bookmark.service';

@Component({
  selector: 'app-stories',
  imports: [FormsModule, RouterModule, CommonModule],
  templateUrl: './stories.html',
  styleUrl: './stories.scss'
})
export class Stories implements OnInit {
  private storyService = inject(StoryService);
  private voteService = inject(VoteService);
  private commentService = inject(CommentService);
  private bookmarkService = inject(BookmarkService);
  private authService = inject(AuthService);
  private profileService = inject(ProfileService); 

  
  // State management
  stories: Story[] = [];
  isLoading = true;
  isLoadingMore = false;
  errorMessage = '';
  hasMoreStories = true;
  currentUser: any = null;


  // Pagination
  storiesPerPage = 10;
  currentPage = 1;

  // Filtering and sorting
  searchQuery = '';
  selectedCategory = '';
  selectedLanguage = '';
  sortType: 'newest' | 'oldest' | 'az' | 'popular' | 'trending' = 'newest';

  // Computed properties
  availableCategories: string[] = [];
  private userBookmarks: Bookmark[] = []; // Store user bookmarks

  // Bookmarked stories (simulated)
  private bookmarkedStories = new Set<string>();

  ngOnInit() {
    this.loadStories();
    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadUserBookmarks(); // Load bookmarks when user is available
      } else {
        this.bookmarkedStories.clear();
        this.userBookmarks = [];
      }
    });
  }

  

  async loadMoreStories() {
    if (!this.hasMoreStories || this.isLoadingMore) return;
    await this.loadStories(true);
  }

  private updateAvailableCategories() {
    const categories = new Set(this.stories.map(story => story.category));
    this.availableCategories = Array.from(categories).sort();
  }
  

  private debounceTimeout?: number;
  private debounceSearch() {
    if (this.debounceTimeout) {
      clearTimeout(this.debounceTimeout);
    }
    this.debounceTimeout = window.setTimeout(() => {
      // Search handling is done in the getter
    }, 300);
  }

  

  private sortStories(a: Story, b: Story): number {
    switch (this.sortType) {
      case 'newest':
        return this.getDateValue(b.createdAt) - this.getDateValue(a.createdAt);
      case 'oldest':
        return this.getDateValue(a.createdAt) - this.getDateValue(b.createdAt);
      case 'az':
        return a.title.toLowerCase().localeCompare(b.title.toLowerCase());
      case 'popular':
      case 'trending':
        const aVotes = a.stats.voteCount || 0;
        const bVotes = b.stats.voteCount || 0;
        if (aVotes !== bVotes) return bVotes - aVotes;
        return this.getDateValue(b.createdAt) - this.getDateValue(a.createdAt);
      default:
        return 0;
    }
  }

  private getDateValue(date: Timestamp | Date): number {
    if (date instanceof Date) return date.getTime();
    if (date && typeof date.toDate === 'function') return date.toDate().getTime();
    return 0;
  }

  

  // Helper methods
  trackByStoryId(index: number, story: Story): string {
    return story.id;
  }

  getAuthorInitials(authorName: string): string {
    return authorName
      .split(' ')
      .map(name => name.charAt(0).toUpperCase())
      .join('')
      .substring(0, 2);
  }

  getCategoryCount(category: string): number {
    return this.stories.filter(story => story.category === category).length;
  }

  formatDate(date: Timestamp | Date): string {
    try {
      const dateObj = date instanceof Date ? date : date.toDate();
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - dateObj.getTime());
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
      const diffHours = Math.floor(diffTime / (1000 * 60 * 60));

      if (diffHours < 1) return 'just now';
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays < 7) return `${diffDays}d ago`;
      
      return dateObj.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric'
      });
    } catch (error) {
      return 'Unknown date';
    }
  }

  getEstimatedReadTime(content: string): number {
    const wordsPerMinute = 200;
    const wordCount = content.split(/\s+/).length;
    return Math.max(1, Math.ceil(wordCount / wordsPerMinute));
  }

  getContentSnippet(content: string, maxLength = 180): string {
    if (!content) return '';
    const stripped = content.replace(/<[^>]*>/g, '');
    return stripped.length > maxLength 
      ? stripped.substring(0, maxLength) + '...' 
      : stripped;
  }

  getLanguageLabel(language: string): string {
    const labels: Record<string, string> = {
      'en': 'English',
      'ar': 'العربية',
      'fr': 'Français'
    };
    return labels[language] || language.toUpperCase();
  }

  formatCount(count: number): string {
    if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toString();
  }

  async loadUserBookmarks() {
    if (!this.currentUser?.uid) return;
    
    try {
      this.userBookmarks = await this.bookmarkService.getUserBookmarks(this.currentUser.uid);
      this.bookmarkedStories.clear();
      console.log(this.userBookmarks);
      // Populate the Set with bookmarked story IDs for quick lookup
      this.userBookmarks.forEach(bookmark => {
        this.bookmarkedStories.add(bookmark.storyId);
      });
    } catch (error) {
      console.error('Error loading user bookmarks:', error);
    }
  }

  isBookmarked(storyId: string): boolean {
    return this.bookmarkedStories.has(storyId);
  }

  // Action handlers
 async toggleBookmark(event: Event, story: Story) {
    event.preventDefault();
    event.stopPropagation();
    
    // Check if user is authenticated
    if (!this.currentUser?.uid) {
      // You can show a login prompt here
      console.log('User must be logged in to bookmark stories');
      return;
    }

    try {
      const isCurrentlyBookmarked = this.isBookmarked(story.id);
      
      if (isCurrentlyBookmarked) {
        // Remove bookmark
        const bookmark = this.userBookmarks.find(b => b.storyId === story.id);
        if (bookmark) {
          await this.bookmarkService.toggleBookmark(bookmark);
          this.bookmarkedStories.delete(story.id);
          // Remove from local array
          this.userBookmarks = this.userBookmarks.filter(b => b.id !== bookmark.id);
        }
      } else {
        // Add bookmark - using your actual Bookmark interface
        const bookmarkData: Bookmark = {
          id: '',
          userId: this.currentUser.uid,
          storyId: story.id,
          title: story.title,
          authorName: story.authorName,
          emoji: story.emoji,
          category: story.category || 'General',
          createdAt: new Date()
        };

        const newBookmarkId = await this.bookmarkService.toggleBookmark(bookmarkData);
        this.bookmarkedStories.add(story.id);
        
        // Add to local array with approximate timestamp
        this.userBookmarks.push({
          ...bookmarkData,
          createdAt: new Date() // Approximate timestamp
        } as Bookmark);
      }
    } catch (error) {
      console.error('Error toggling bookmark:', error);
      // Optionally show user feedback about the error
    }
  }

  shareStory(event: Event, story: Story) {
    event.preventDefault();
    event.stopPropagation();
    
    if (navigator.share) {
      navigator.share({
        title: story.title,
        url: window.location.origin + '/story/' + story.id
      });
    } else {
      const url = window.location.origin + '/story/' + story.id;
      navigator.clipboard.writeText(url).then(() => {
      });
    }
  }

  scrollSlider(direction: number) {
  const slider = document.querySelector('.quick-filters-slider') as HTMLElement;
  if (slider) {
    const scrollAmount = 200; // Adjust as needed
    slider.scrollBy({ left: direction * scrollAmount, behavior: 'smooth' });
  }
}

private allStoriesLoaded = false;

  async loadStories(append = false) {
    try {
      if (!append) {
        this.isLoading = true;
        this.errorMessage = '';
        this.allStoriesLoaded = false;
        // Reset service pagination when loading fresh data
        this.storyService.resetPagination();
      } else {
        this.isLoadingMore = true;
      }
  
      // Fetch stories with pagination
      const loadedStories = await this.storyService.getStories(20, append);
      
      // If we get fewer stories than requested, we've reached the end
      if (loadedStories.length < 20) {
        this.allStoriesLoaded = true;
      }
  
      // Add voteCount to each story
      const storiesWithVotes = await Promise.all(
        loadedStories.map(async (story) => {
          try {
            const count = await this.voteService.countVotes(story.id);
            const commentCount = await this.commentService.countComments(story.id);
            return { ...story, voteCount: count , commentCount: commentCount};
          } catch (error) {
            console.error(`Error loading vote count for story ${story.id}:`, error);
            return { ...story, voteCount: 0, commentCount:0 };
          }
        })
      );
  
      // Append or replace stories
      if (append) {
        this.stories = [...this.stories, ...storiesWithVotes];
      } else {
        this.stories = storiesWithVotes;
      }
  
      // Update UI state
      this.updateAvailableCategories();
      this.hasMoreStories = !this.allStoriesLoaded;
  
    } catch (error) {
      console.error('Error loading stories:', error);
      this.errorMessage = 'Failed to load stories. Please try again later.';
    } finally {
      this.isLoading = false;
      this.isLoadingMore = false;
    }
  }

  // Update the filteredStories getter to remove pagination logic
  get filteredStories(): Story[] {
    return this.stories
      .filter(story => {
        if (story.status !== StoryStatus.PUBLISHED) return false;

        if (this.searchQuery) {
          const q = this.searchQuery.toLowerCase();
          const matchesSearch =
            story.title.toLowerCase().includes(q) ||
            story.content.toLowerCase().includes(q) ||
            story.authorName.toLowerCase().includes(q) ||
            (story.tags && story.tags.some(tag => tag.toLowerCase().includes(q)));
          
          if (!matchesSearch) return false;
        }

        if (this.selectedCategory && story.category !== this.selectedCategory) {
          return false;
        }

        if (this.selectedLanguage && story.language !== this.selectedLanguage) {
          return false;
        }

        return true;
      })
      .sort((a, b) => this.sortStories(a, b));
  }

  // Update methods that change filters to reset pagination
  onSearchChange() {
    this.storyService.resetPagination();
    this.debounceSearch();
  }

  onFilterChange() {
    this.storyService.resetPagination();
  }

  onSortChange() {
    this.storyService.resetPagination();
  }

  // Update the template to show all filtered stories without pagination
  get paginatedStories(): Story[] {
    // Remove the pagination logic and return all filtered stories
    // The "Load More" button will now load more stories from Firestore
    return this.filteredStories;
  }

  clearSearch() {
  this.searchQuery = '';
  this.storyService.resetPagination();
  this.onSearchChange();
}

clearAllFilters() {
  this.searchQuery = '';
  this.selectedCategory = '';
  this.selectedLanguage = '';
  this.sortType = 'newest';
  this.storyService.resetPagination();
  this.loadStories(); // Reload fresh data
}

selectCategory(category: string) {
  this.selectedCategory = category;
  this.storyService.resetPagination();
  this.onFilterChange();
}
}