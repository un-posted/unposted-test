import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { getAuth, UserProfile } from '@angular/fire/auth';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { Story, Bookmark } from '../../models';
import { ProfileService } from '../../services/profile.service';
import { ViewsService } from '../../services/views.service';
import { VoteService } from '../../services/vote.service';
import { AuthService } from '../../services/auth.service';
import { StoryService } from '../../services/story.service';
import { BookmarkService } from '../../services/bookmark.service';
import { FollowService } from '../../services/follow.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';


interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  requirement?: number;
}

@Component({
  selector: 'app-profile',
  imports: [FormsModule, CommonModule],
  templateUrl: './profile.html',
  styleUrl: './profile.scss'
})
export class Profile implements OnInit, OnDestroy {
    
  @ViewChild('nameInput') nameInput!: ElementRef;
  @ViewChild('bioInput') bioInput!: ElementRef;

  currentUser = getAuth().currentUser;

  // Component state
  userProfile: any = null;
  stories: Story[] = [];
  drafts: Story[] = [];
  bookmarks: Bookmark[] = [];
  
  activeTab: 'drafts' | 'articles' | 'bookmarks' = 'drafts';
  loading = true;
  savingProfile = false;
  
  // Edit state
  editingName = false;
  editingBio = false;
  tempName = '';
  tempBio = '';

  // Gamification state
  badges: Badge[] = [];
  isOwnProfile = false;
  isFollowing = false;
  followLoading = false;

  // Default avatar
  defaultAvatar = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIwIiBoZWlnaHQ9IjEyMCIgdmlld0JveD0iMCAwIDEyMCAxMjAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjAiIGhlaWdodD0iMTIwIiByeD0iNjAiIGZpbGw9IiNlNmIxN2EiLz4KPHN2ZyB4PSIzMCIgeT0iMzAiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSI+CjxwYXRoIGQ9Im0zIDkgOS0xIDktMW0tMSAyIDEwIDEwaDEwbC04LTEwbS0xLTEwSDhsLTggMTB2MTBsOC0xMVoiLz4KPC9zdmc+Cjwvc3ZnPgo=';
  
  private destroy$ = new Subject<void>();

  constructor(
    private profileService: ProfileService,
    private route: ActivatedRoute,
    private viewsService: ViewsService,
    private voteService: VoteService,
    private storyService: StoryService,
    private bookmarkService: BookmarkService,
    private authService: AuthService,
    private followService: FollowService,
    private router: Router
  ) {}

  ngOnInit() {
  const currentUserId = this.authService.user?.uid || this.currentUser?.uid || '';

  this.route.paramMap
    .pipe(takeUntil(this.destroy$))
    .subscribe(async paramMap => {
      const uid = paramMap.get('id');

      // Set isOwnProfile BEFORE calling loadProfileData
      this.isOwnProfile = (!uid || uid === currentUserId);

      const targetUid = uid || currentUserId;
      if (!targetUid) {
        this.userProfile = null;
        this.loading = false;
        return;
      }

      // Set default tab based on profile type
      if (!this.isOwnProfile && this.activeTab !== 'articles') {
        this.activeTab = 'articles'; // Default to articles for other users
      }

      await this.loadProfileData(targetUid);
    });
}

ngOnDestroy() {
  this.destroy$.next();
  this.destroy$.complete();
}


  async loadProfileData(uid?: string) {
    this.loading = true;
    try {
      // Fix: Don't fall back to current user when viewing other profiles
      const targetUid =
        uid ||
        sessionStorage.getItem('currentUserId') ||
        this.currentUser?.uid ||
        '';

      if (!targetUid) {
        this.userProfile = null;
        this.loading = false;
        return;
      }

      const profile = await this.profileService.getProfile(targetUid);

      if (!profile) {
        this.userProfile = null;
        this.loading = false;
        return;
      }

      // Initialize stats if missing
      //if (!profile?.stats) {
        //profile.stats = {
          //storiesPublished: 0,
         // draftsCount: 0,
         // bookmarksCount: 0,
         // totalViews: 0,
         // totalVotes: 0,
         // followersCount: 0,
         // followingCount: 0,
       // };
     // }

      this.userProfile = profile;
      console.log(this.userProfile)
      console.log(profile)
      this.initializeBadges();

      // Load appropriate data based on profile ownership
      let loadPromises: [
        Promise<Story[]>,
        Promise<Story[]>,
        Promise<Bookmark[]>
      ];

      if (this.isOwnProfile) {
        // Only load private data (drafts, bookmarks) for own profile
        loadPromises = [
          this.storyService.getDraftsByAuthor(targetUid),
          this.storyService.getPublishedByAuthor(targetUid),
          this.bookmarkService.getUserBookmarks(targetUid),
        ];
      } else {
        // For other users, only load public stories
        loadPromises = [
          Promise.resolve([] as Story[]),
          this.storyService.getPublishedByAuthor(targetUid),
          Promise.resolve([] as Bookmark[]),
        ];
      }

      const [drafts, stories, bookmarks] = await Promise.all(loadPromises);

      this.drafts = drafts;
      this.stories = stories;
      this.bookmarks = bookmarks;

      // Load view counts for stories
      await this.loadStoryViewCounts();
      // Update badge progress with available data
      this.updateBadgeProgress();

      // Check if following (for other users' profiles)
      if (!this.isOwnProfile && this.currentUser) {
        this.isFollowing = await this.followService.isFollowing(this.currentUser.uid, targetUid);
      }
    } catch (e) {
      console.error('Error loading profile:', e);
      this.userProfile = null;
    } finally {
      this.loading = false;
    }

    console.log(this.userProfile)
    console.log(this.userProfile?.photoURL)
  }
  

  async loadStoryViewCounts() {
    for (const story of this.stories) {
      try {
        story.stats.readCount = await this.viewsService.getViewCount(story.id);
        
        story.stats.voteCount = await this.voteService.countVotes(story.id);
      } catch (error) {
        console.error('Error loading view count for story:', story.id, error);
        story.stats.readCount = 0;
      }
    }
  }

  async toggleFollow() {
    if (!this.currentUser || !this.userProfile || this.isOwnProfile) return;

    const me = this.currentUser.uid;
    const them = this.userProfile.uid;

    this.followLoading = true;
    try {
      if (this.isFollowing) {
        await this.followService.toggleFollow(me, them);
        this.userProfile.stats.followersCount--;
        this.isFollowing = false;
      } else {
        await this.followService.toggleFollow(me, them);
        this.userProfile.stats.followersCount++;
        this.isFollowing = true;
      }
    } catch (error) {
      console.error('Error toggling follow:', error);
    } finally {
      this.followLoading = false;
    }
  }

  // Enhanced streak tracking with timezone awareness
  async updateWritingStreak() {
    if (!this.currentUser || !this.isOwnProfile || !this.userProfile) return;
    
    try {
      const today = this.getCurrentDate();
      const lastWriteDate = this.userProfile.lastWriteDate 
        ? this.formatDateForComparison(this.userProfile.lastWriteDate)
        : null;

      // If user already wrote today, no need to update
      if (lastWriteDate === today) return;

      const yesterday = this.getYesterdayDate();
      let newStreak = 1;
      let streakBroken = false;
      
      // If last write was yesterday, continue streak
      if (lastWriteDate === yesterday) {
        newStreak = (this.userProfile.writingStreak || 0) + 1;
      } else if (lastWriteDate && lastWriteDate < yesterday) {
        // Streak broken if more than 1 day has passed
        streakBroken = true;
        newStreak = 1;
      }
      
      // Update streak in profile
      if (this.currentUser) {
        await this.profileService.updateProfile(this.currentUser.uid, {
          streaks: newStreak,
          lastWriteDay: new Date()
        });
      }

      // Update local profile
      this.userProfile.writingStreak = newStreak;
      this.userProfile.lastWriteDate = new Date().toISOString();

      // Award XP for maintaining streak or notify about broken streak
      if (streakBroken) {
        this.showStreakBrokenNotification(this.userProfile.writingStreak || 0);
      } else if (newStreak > 1) {
        await this.awardStreakXP(newStreak);
      }
    } catch (error) {
      console.error('Error updating writing streak:', error);
    }
  }

  // Helper methods for date handling
  private getCurrentDate(): string {
    const now = new Date();
    return now.toLocaleDateString('en-CA'); // YYYY-MM-DD format
  }

  private getYesterdayDate(): string {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.toLocaleDateString('en-CA');
  }

  private formatDateForComparison(date: any): string {
    const dateObj = date.toDate ? date.toDate() : new Date(date);
    return dateObj.toLocaleDateString('en-CA');
  }

  // Enhanced XP awarding for streaks
  private async awardStreakXP(currentStreak: number) {
    let xpAmount = 0;
    let reason = '';
    
    // Award bonus XP for milestone streaks
    if (currentStreak % 30 === 0) {
      xpAmount = 200;
      reason = `Maintained ${currentStreak}-day writing streak (monthly milestone)`;
    } else if (currentStreak % 7 === 0) {
      xpAmount = 50;
      reason = `Maintained ${currentStreak}-day writing streak (weekly milestone)`;
    } else if (currentStreak === 1) {
      xpAmount = 10;
      reason = 'Started a new writing streak';
    } else {
      // Small XP for daily consistency
      xpAmount = 5;
      reason = `Maintained ${currentStreak}-day writing streak`;
    }
    
    if (xpAmount > 0) {
      await this.awardXP(xpAmount, reason);
    }
  }

  private showStreakBrokenNotification(previousStreak: number) {
    if (previousStreak > 3) {
      // Only notify if they had a meaningful streak
      console.log(`Your ${previousStreak}-day writing streak was broken! Start a new one today!`);
    }
  }

  // Check if streak is still valid (written today or yesterday)
  isStreakCurrent(): boolean {
    if (!this.userProfile?.lastWriteDate) return false;
    
    const lastWriteDate = new Date(this.userProfile.lastWriteDate);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    return (
      lastWriteDate.toDateString() === today.toDateString() ||
      lastWriteDate.toDateString() === yesterday.toDateString()
    );
  }

  // Get appropriate streak icon based on streak length
  getStreakIcon(streak: number): string {
    if (streak >= 100) return '🏆';
    if (streak >= 30) return '🌟';
    if (streak >= 7) return '🔥';
    return '📅';
  }

  // Gamification methods
  initializeBadges() {
    this.badges = [
      {
        id: 'first-draft',
        name: 'First Draft',
        description: 'Created your first draft',
        icon: '📝',
        unlocked: false
      },
      {
        id: 'first-publish',
        name: 'Author',
        description: 'Published your first story',
        icon: '📚',
        unlocked: false
      },
      {
        id: 'prolific-writer',
        name: 'Prolific Writer',
        description: 'Published 5 stories',
        icon: '✍️',
        unlocked: false,
        progress: 0,
        requirement: 5
      },
      {
        id: 'word-master',
        name: 'Word Master',
        description: 'Written 10,000 words total',
        icon: '📖',
        unlocked: false,
        progress: 0,
        requirement: 10000
      },
      {
        id: 'streak-novice',
        name: 'Consistent Writer',
        description: 'Maintained a 3-day writing streak',
        icon: '📅',
        unlocked: false,
        progress: 0,
        requirement: 3
      },
      {
        id: 'streak-warrior',
        name: 'Streak Warrior',
        description: 'Maintained a 7-day writing streak',
        icon: '🔥',
        unlocked: false,
        progress: 0,
        requirement: 7
      },
      {
        id: 'streak-champion',
        name: 'Streak Champion',
        description: 'Maintained a 30-day writing streak',
        icon: '🏆',
        unlocked: false,
        progress: 0,
        requirement: 30
      },
      {
        id: 'streak-legend',
        name: 'Writing Legend',
        description: 'Maintained a 100-day writing streak',
        icon: '🌟',
        unlocked: false,
        progress: 0,
        requirement: 100
      },
      {
        id: 'community-favorite',
        name: 'Community Favorite',
        description: 'Received 100 total votes',
        icon: '⭐',
        unlocked: false,
        progress: 0,
        requirement: 100
      },
      {
        id: 'bookworm',
        name: 'Bookworm',
        description: 'Bookmarked 20 stories',
        icon: '🔖',
        unlocked: false,
        progress: 0,
        requirement: 20
      }
    ];
  }

  // Enhanced badge progress with streak validation
  updateBadgeProgress() {
    if (!this.userProfile) return;

    const stats = this.userProfile.stats || {};
    //const totalWords = this.calculateTotalWords();
    const totalWords = 0;
    const totalVotes = this.calculateTotalVotes();
    const totalViews = this.calculateTotalViews();

    // Update badge progress
    this.badges.forEach(badge => {
      switch (badge.id) {
        case 'first-draft':
          badge.unlocked = (this.drafts.length || 0) > 0;
          break;
        case 'first-publish':
          badge.unlocked = (this.stories.length || 0) > 0;
          break;
        case 'prolific-writer':
          badge.progress = Math.min(this.stories.length || 0, badge.requirement!);
          badge.unlocked = (this.stories.length || 0) >= badge.requirement!;
          break;
        case 'word-master':
          badge.progress = Math.min(totalWords, badge.requirement!);
          badge.unlocked = totalWords >= badge.requirement!;
          break;
        case 'streak-novice':
        case 'streak-warrior':
        case 'streak-champion':
        case 'streak-legend':
          // Enhanced streak validation - ensure streak is current
          const currentStreak = this.isStreakCurrent() ? this.userProfile?.writingStreak || 0 : 0;
          badge.progress = Math.min(currentStreak, badge.requirement!);
          badge.unlocked = currentStreak >= badge.requirement!;
          break;
        case 'community-favorite':
          badge.progress = Math.min(totalVotes, badge.requirement!);
          badge.unlocked = totalVotes >= badge.requirement!;
          break;
        case 'bookworm':
          badge.progress = Math.min(stats.bookmarksCount || 0, badge.requirement!);
          badge.unlocked = (stats.bookmarksCount || 0) >= badge.requirement!;
          break;
      }
    });
  }

  //calculateTotalWords(): number {
    //return [...this.drafts, ...this.stories].reduce((total, item) => {
     // const count = item.stats.wordCount 
       // ? Number(item.stats.wordCount) 
       // : (item.content ? item.content.trim().split(/\s+/).length : 0);

     // return total + count;
    //}, 0);
  //}

  calculateTotalVotes(): number {
    return this.stories.reduce((total, story) => {
      return total + (story.stats.voteCount || 0);
    }, 0);
  }

  calculateTotalViews(): number {
    return this.stories.reduce((total, story) => {
      return total + (story.stats.readCount || 0);
    }, 0);
  }

  getXPProgress(): number {
    if (!this.userProfile) return 0;
    
    const currentXP = this.userProfile.totalXP || 0;
    const currentLevel = this.userProfile.level || 1;
    const currentLevelXP = this.getLevelXP(currentLevel);
    const nextLevelXP = this.getNextLevelXP();
    
    const levelXPRange = nextLevelXP - currentLevelXP;
    const currentLevelProgress = currentXP - currentLevelXP;
    
    return Math.max(0, Math.min(100, (currentLevelProgress / levelXPRange) * 100));
  }

  getLevelXP(level: number): number {
    // XP required to reach this level (cumulative)
    return Math.pow(level - 1, 2) * 100;
  }

  getNextLevelXP(): number {
    const currentLevel = this.userProfile?.level || 1;
    return this.getLevelXP(currentLevel + 1);
  }

  // Enhanced motivation messages with streak focus
  getMotivationMessage(): string {
    if (!this.userProfile || !this.isOwnProfile) return '';

    const stats = this.userProfile.stats || {};
    const currentStreak = this.userProfile.writingStreak || 0;
    const unlockedBadges = this.badges.filter(b => b.unlocked).length;
    const totalBadges = this.badges.length;

    // Streak-specific motivation
    if (currentStreak > 0) {
      if (this.isStreakCurrent()) {
        if (currentStreak === 1) {
          return "You started a streak! Write again tomorrow to keep it going!";
        } else if (currentStreak < 3) {
          return `Keep your ${currentStreak}-day streak alive! ${3 - currentStreak} more days until your first streak badge!`;
        } else if (currentStreak < 7) {
          return `Keep your ${currentStreak}-day streak alive! ${7 - currentStreak} more days until Streak Warrior!`;
        } else if (currentStreak < 30) {
          return `Amazing ${currentStreak}-day streak! ${30 - currentStreak} more days until Streak Champion!`;
        } else if (currentStreak < 100) {
          return `Incredible ${currentStreak}-day streak! ${100 - currentStreak} more days until Writing Legend!`;
        } else {
          return `You're a Writing Legend with ${currentStreak} days! Keep the momentum going!`;
        }
      } else {
        return "Your streak is about to break! Write something today to keep it going!";
      }
    }

    // Check for near achievements (prioritize streak-related)
    const nearAchievements = this.badges.filter(badge => 
      !badge.unlocked && 
      badge.progress !== undefined && 
      badge.requirement !== undefined
    ).sort((a, b) => {
      // Prioritize streak-related badges
      if (a.id.includes('streak')) return -1;
      if (b.id.includes('streak')) return 1;
      return (b.progress! / b.requirement!) - (a.progress! / a.requirement!);
    });

    if (nearAchievements.length > 0) {
      const badge = nearAchievements[0];
      const progressPercentage = (badge.progress! / badge.requirement!) * 100;
      
      if (progressPercentage >= 80) {
        const remaining = badge.requirement! - badge.progress!;
        return `You're ${remaining} away from "${badge.name}"! ${this.getBadgeHint(badge.id)}`;
      }
    }

    // General encouragement
    if (this.drafts.length === 0) {
      return "Start a writing streak today! Create your first draft!";
    }

    if (this.stories.length === 0 && this.drafts.length > 0) {
      return "Publish a draft to start building your writing reputation!";
    }

    if (unlockedBadges < totalBadges) {
      return `${totalBadges - unlockedBadges} achievements waiting! Consistency is key.`;
    }

    return "Keep up the great work! Your consistency is inspiring.";
  }

  private getBadgeHint(badgeId: string): string {
    const hints: { [key: string]: string } = {
      'streak-novice': 'Write for 3 consecutive days!',
      'streak-warrior': 'Write every day for a full week!',
      'streak-champion': 'Maintain your daily writing for a month!',
      'streak-legend': 'The ultimate challenge - 100 days of writing!',
      'prolific-writer': 'Publish more stories to reach your goal!',
      'word-master': 'Keep writing - every word counts!',
      'community-favorite': 'Engage with the community to get more votes!',
      'bookworm': 'Discover and bookmark great content!'
    };
    
    return hints[badgeId] || '';
  }

  formatNumber(num: number | null | undefined): string {
    if (num === null || num === undefined) return "0";

    if (num >= 1_000_000) {
      return (num / 1_000_000).toFixed(1) + "M";
    }
    if (num >= 1_000) {
      return (num / 1_000).toFixed(1) + "K";
    }
    return num.toString();
  }

  // Tab navigation
  setActiveTab(tab: 'drafts' | 'articles' | 'bookmarks') {
    this.activeTab = tab;
  }

  // Profile editing methods
  startEditingName() {
    if (!this.isOwnProfile) return;
    
    this.editingName = true;
    this.tempName = this.userProfile?.displayName || '';
    setTimeout(() => {
      this.nameInput?.nativeElement?.focus();
    });
  }

  async saveName() {
    if (!this.userProfile || !this.tempName.trim() || !this.isOwnProfile) return;
    
    this.savingProfile = true;
    try {
        if (this.currentUser) {
            await this.profileService.updateProfile(this.currentUser.uid, {
              name: this.tempName.trim()
            });
      }
      
      if (this.userProfile) {
        this.userProfile.displayName = this.tempName.trim();
      }
      this.editingName = false;
    } catch (error) {
      console.error('Error updating name:', error);
    } finally {
      this.savingProfile = false;
    }
  }

  cancelNameEdit() {
    this.editingName = false;
    this.tempName = '';
  }

  startEditingBio() {
    if (!this.isOwnProfile) return;
    
    this.editingBio = true;
    this.tempBio = this.userProfile?.bio || '';
    setTimeout(() => {
      this.bioInput?.nativeElement?.focus();
    });
  }

  async saveBio() {
    if (!this.userProfile || !this.isOwnProfile) return;
    
    this.savingProfile = true;
    try {
        if (this.currentUser) {
      await this.profileService.updateProfile(this.currentUser.uid, {
        bio: this.tempBio.trim()
      });}
      
      if (this.userProfile) {
        this.userProfile.bio = this.tempBio.trim();
      }
      this.editingBio = false;
    } catch (error) {
      console.error('Error updating bio:', error);
    } finally {
      this.savingProfile = false;
    }
  }

  cancelBioEdit() {
    this.editingBio = false;
    this.tempBio = '';
  }

  // Enhanced draft methods with streak tracking
  async createNewDraft() {
    try {
      // Navigate to draft creation
      this.router.navigate(['/editor']);
      
      // Award XP for creating a draft
      await this.awardXP(10, 'Created a new draft');
      await this.updateWritingStreak();
    } catch (error) {
      console.error('Error creating new draft:', error);
    }
  }

  editDraft(draft: Story) {
    // Navigate to draft editor
    this.router.navigate(['/editor', draft.id]);
  }

  async publishDraft(draft: Story) {
    try {
      await this.storyService.updateStory(draft.id,{
        status : 'published'
      });
      
      // Award XP for publishing
      await this.awardXP(25, 'Published a story');
      
      // Update writing streak
      await this.updateWritingStreak();
      
      // Reload data to reflect changes
      this.loadProfileData();
    } catch (error) {
      console.error('Error publishing draft:', error);
    }
  }

  //async deleteDraft(draft: Story) {
    //if (!confirm('Are you sure you want to delete this draft?')) return;
    
   // try {
    //  await this.storyService.deleteDraft(draft.id);
    //  this.drafts = this.drafts.filter(d => d.id !== draft.id);
    //} catch (error) {
     // console.error('Error deleting draft:', error);
    //}
  //}

  // Bookmark methods
  readBookmark(bookmark: Bookmark) {
    if(bookmark.storyId) {
      // Navigate to internal story
      this.router.navigate(['/story/', bookmark.storyId]);
    }
  }

  editBookmark(bookmark: Bookmark) {
    // Open edit modal or navigate to edit page
    console.log('Edit bookmark:', bookmark.id);
  }

  //async removeBookmark(bookmark: Bookmark) {
    //if (!confirm('Remove this bookmark?')) return;
    
    //try {
    //  await this.profileService.deleteBookmark(bookmark.id);
    //  this.bookmarks = this.bookmarks.filter(b => b.id !== bookmark.id);
      
      // Award XP for bookmarking activity
     // await this.awardXP(5, 'Removed a bookmark');
    //} catch (error) {
     // console.error('Error removing bookmark:', error);
    //}
  //}

  // XP and leveling system
  async awardXP(amount: number, reason: string) {
    if (!this.currentUser || !this.userProfile) return;
    
    try {
      await this.profileService.awardUserXP(this.currentUser.uid, amount, reason);
      
      // Update local profile
      const oldLevel = this.userProfile.level || 1;
      this.userProfile.totalXP = (this.userProfile.totalXP || 0) + amount;
      this.userProfile.level = this.calculateLevel(this.userProfile.totalXP);
      
      // Check for level up
      if (this.userProfile.level > oldLevel) {
        this.showLevelUpNotification(this.userProfile.level);
      }
    } catch (error) {
      console.error('Error awarding XP:', error);
    }
  }

  calculateLevel(totalXP: number): number {
    // Level = sqrt(totalXP / 100) + 1, rounded down
    return Math.floor(Math.sqrt(totalXP / 100)) + 1;
  }

  showLevelUpNotification(newLevel: number) {
    // This could trigger a modal, toast, or other notification
    console.log(`Level up! You're now level ${newLevel}!`);
    
    // For a real implementation, you might use:
    // this.notificationService.show(`Level up! You're now level ${newLevel}!`, 'success');
  }

  // Utility methods
  formatDate(date: any): string {
    if (!date) return '';
    
    const dateObj = date.toDate ? date.toDate() : new Date(date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - dateObj.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  }

  getExcerpt(content: string, maxLength = 150): string {
    if (!content) return '';
    
    const plainText = content.replace(/<[^>]*>/g, ''); // Remove HTML tags
    return plainText.length > maxLength 
      ? plainText.substring(0, maxLength) + '...'
      : plainText;
  }

  calculateReadTime(content: string): number {
    if (!content) return 0;
    
    const words = content.trim().split(/\s+/).length;
    return Math.ceil(words / 200); // Assuming 200 words per minute
  }
}