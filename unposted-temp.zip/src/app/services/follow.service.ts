// services/follow.service.ts
import { Injectable, inject } from '@angular/core';
import { Firestore, doc, setDoc, deleteDoc, getDoc, updateDoc, increment } from '@angular/fire/firestore';
import { Follow } from '../models/follow';

@Injectable({ providedIn: 'root' })
export class FollowService {
  private firestore = inject(Firestore);

  async toggleFollow(followerId: string, followingId: string): Promise<void> {
    if (followerId === followingId) {
      throw new Error('Cannot follow yourself');
    }

    const ref = doc(this.firestore, `follows/${followerId}_${followingId}`);
    const snap = await getDoc(ref);

    const profileRef = doc(this.firestore, `profiles/${followingId}`);

    if (snap.exists()) {
      await deleteDoc(ref);
      await updateDoc(profileRef, { nbFollowers: increment(-1) });
    } else {
      const follow: Follow = {
        id: `${followerId}_${followingId}`,
        followerId,
        followingId,
        createdAt: new Date()
      };
      await setDoc(ref, follow);
      await updateDoc(profileRef, { nbFollowers: increment(1) });
    }
  }

  async isFollowing(followerId: string, followingId: string): Promise<boolean> {
    if (followerId === followingId) {
      return false; // Users can't follow themselves
    }
    
    const ref = doc(this.firestore, `follows/${followerId}_${followingId}`);
    const snap = await getDoc(ref);
    
    return snap.exists();
  }
}
