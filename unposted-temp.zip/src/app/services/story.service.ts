// services/story.service.ts
import { Injectable, inject } from '@angular/core';
import { Firestore, doc, setDoc, getDoc, updateDoc, addDoc, collection, serverTimestamp, getDocs, query, where, DocumentData, QueryDocumentSnapshot, limit, orderBy, startAfter } from '@angular/fire/firestore';
import { Story } from '../models';

@Injectable({ providedIn: 'root' })
export class StoryService {
  private firestore = inject(Firestore);

  async createStory(story: Story): Promise<string> {
    const ref = doc(this.firestore, `stories/${story.id}`);
    await setDoc(ref, {
      ...story,
      createdAt: new Date(),
      updatedAt: new Date()
    });
    return story.id;
  }

  async updateStory(storyId: string, data: Partial<Story>): Promise<void> {
    const ref = doc(this.firestore, `stories/${storyId}`);
    await updateDoc(ref, { ...data, updatedAt: new Date() });
  }

  async getStory(storyId: string): Promise<Story | null> {
    const ref = doc(this.firestore, `stories/${storyId}`);
    const snap = await getDoc(ref);
    return snap.exists() ? (snap.data() as Story) : null;
  }

  async getDraftsByAuthor(authorId: string): Promise<Story[]> {
    const storiesRef = collection(this.firestore, 'stories');
    const q = query(storiesRef, where('authorId', '==', authorId), where('status', '==', 'draft'));
    const snap = await getDocs(q);

    return snap.docs.map(doc => doc.data() as Story);
  }

  async getPublishedByAuthor(authorId: string): Promise<Story[]> {
    const storiesRef = collection(this.firestore, 'stories');
    const q = query(storiesRef, where('authorId', '==', authorId), where('status', '==', 'published'));
    const snap = await getDocs(q);

    return snap.docs.map(doc => doc.data() as Story);
  }

  private lastDoc: QueryDocumentSnapshot<DocumentData> | null = null;
  private hasMore = true;

  resetPagination(): void {
    this.lastDoc = null;
    this.hasMore = true;
  }

  async getStories(pageSize: number, append = false): Promise<Story[]> {
    if (!this.hasMore) return [];

    const storiesRef = collection(this.firestore, 'stories');
    let q;

    if (this.lastDoc) {
      q = query(
        storiesRef,
        orderBy('createdAt', 'desc'),
        startAfter(this.lastDoc),
        limit(pageSize)
      );
    } else {
      q = query(storiesRef, orderBy('createdAt', 'desc'), limit(pageSize));
    }

    const snap = await getDocs(q);
    const stories = snap.docs.map(
      doc => ({ id: doc.id, ...doc.data() } as Story)
    );

    // Update pagination state
    this.lastDoc =
      snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : this.lastDoc;
    if (snap.docs.length < pageSize) {
      this.hasMore = false;
    }

    return append ? stories : [...stories];
  }
}
